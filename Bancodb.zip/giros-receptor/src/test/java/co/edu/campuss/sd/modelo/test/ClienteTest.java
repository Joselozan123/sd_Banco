package co.edu.campuss.sd.modelo.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import co.edu.campuss.sd.modelo.Cliente;
import co.edu.campuss.sd.modelo.daos.ClienteDAO;



class ClienteTest {

	@Test
	void testPersist() {
		ClienteDAO dao = new ClienteDAO();
		Cliente o = new Cliente();
		
		o.setIdCliente("1");
		

		try {
			dao.persist(o);
			assertTrue(true);

		} catch (Exception e) {

			fail(e.toString());
		}
	}

}
